// 创建一个类
window.onload = function () {
    class Manager {
        constructor(data) {
            this.data = data;
            this.root = null;
        }
        init() {
            this.render();
            this.moveEvent();
        }
        render() {
            // 根据数据渲染页面
            let html = this.data.map((ele, index) => {
                return `
<li class=${index==0?"list":"" }>
    <div class="title ${index==0 ?"active":""}">
        <i>${ele.num}</i>
        <p>${ele.name}</p>
        <span>${ele.priceA}</span>
    </div>
    <div class="con">
        <i class="sjx"></i>
        <span class="number">${ele.num}</span>
        <img src=${ele.src} alt="">
        <p class="p1">${ele.title}</p>
        <p class="goods_price">${ele.priceB}</p>
        <span class="triangle"></span>
        <p class="p2">${ele.dis1}</p>
        <p class="p3">${ele.dis2}</p>
        <div class="ph_evaluter">
            <span>
                <p class="better_evaluter" style="width: ${ele.pj}"></p>
            </span>
            <p>好评<i>(${ele.pj})</i></p>
        </div>
        <div class="getxinde">
           <p class="p4"><span>${ele.xd}</span>使用心得</p>
            <p class="p5"><span>${ele.zx}</span>咨询</p>
        </div>
    </div>
</li>
            `
            }).join("");
            // 获取页面中的标签
            let oDiv = document.querySelector(".box");
            // 创建一个ul标签
            this.root = document.createElement("ul");
            this.root.className = "box1";
            // 设置ul的内容
            this.root.innerHTML = html;
            // 插到页面上去
            oDiv.appendChild(this.root);
        }
        moveEvent() {
            // 先获取标签
            let oLis = this.root.children;
            let oTitles = this.root.querySelectorAll(".title");
            let oCons = this.root.querySelectorAll(".con");
            // 给每一个li一个移动事件
            let self = this;
            Array.from(oTitles).forEach((ele, index) => {
                ele.onmouseenter = function () {
                    // 排他显示当前
                    Array.from(oLis).forEach(ele => ele.classList.remove("list"));
                    Array.from(oTitles).forEach(ele => ele.classList.remove("active"));
                    this.parentElement.classList.add("list");
                    this.classList.add("active");
                }
            })
        }
    }
    // 实列化一个对象
    let manager1 = new Manager(data1);
    manager1.init();
    // 实列化二个对象
    let manager2 = new Manager(data2);
    manager2.init();
    // 实列化第三个对象
    let manager3 = new Manager(data3);
    manager3.init();
    // 实列化第四个对象
    let manager4 = new Manager(data4);
    manager4.init();
}