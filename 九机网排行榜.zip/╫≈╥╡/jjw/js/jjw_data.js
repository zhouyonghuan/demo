let data1 = [{
    "name": "华为 Mate 30 （TAS-AN00）全网通5G版",
    "priceA": "￥5499.00",
    "num": "1",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191106094800559.jpg",
    "title": "华为 Mate 30 （TAS-AN00）全网通5G版",
    "priceB": "￥5499.00",
    "dis1": "1、麒麟990 5G芯片",
    "dis2": "2、27W超级无线充",
    "pj": "99%",
    "xd": "593",
    "zx": "1"
}, {
    "name": "Apple iPhone 11 （A2223）全网通",
    "priceA": "￥5199.00",
    "num": "2",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190911103416335.jpg",
    "title": "Apple iPhone 11 （A2223）全网通",
    "priceB": "￥5199.00",
    "dis1": "1、A13 仿生芯片",
    "dis2": "2、1200万后置双摄",
    "pj": "98%",
    "xd": "6570",
    "zx": "0"
}, {
    "name": "一加手机 7T （HD1900）全网通版",
    "priceA": "￥3199.00",
    "num": "3",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191015171720571.jpg",
    "title": "一加手机 7T （HD1900）全网通版",
    "priceB": "￥3199.00",
    "dis1": "1、骁龙855 Plus旗舰",
    "dis2": "2、4800万超广角三摄",
    "pj": "98%",
    "xd": "343",
    "zx": "0"
}, {
    "name": "华为 荣耀9X （HLK-AL00）全网通版",
    "priceA": "￥1799.00",
    "num": "4",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190723161722265.jpg",
    "title": "华为 荣耀9X （HLK-AL00）全网通版",
    "priceB": "￥1799.00",
    "dis1": "1、海思麒麟810",
    "dis2": "2、升降式摄像头",
    "pj": "98%",
    "xd": "1519",
    "zx": "0"
}, {
    "name": "华为 P30 （ELE-AL00）全网通版",
    "priceA": "￥3988.00",
    "num": "5",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190512230954370.jpg",
    "title": "华为 P30 （ELE-AL00）全网通版",
    "priceB": "￥3988.00",
    "dis1": "1、海思麒麟980",
    "dis2": "2、30倍变焦摄像",
    "pj": "99%",
    "xd": "3096",
    "zx": "5"
}]
let data2 = [{
    "name": "华为 Mate 30 Pro （LIO-AN00）全网通5G版",
    "priceA": "￥6899.00",
    "num": "1",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191106094958881.jpg",
    "title": "华为 Mate 30 Pro （LIO-AN00）全网通5G版",
    "priceB": "￥6899.00",
    "dis1": "1、超曲面环幕屏\n",
    "dis2": "2、后置徕卡四摄",
    "pj": "99%",
    "xd": "665",
    "zx": "1"
}, {
    "name": "Apple iPhone 11 Pro Max （A2220）全网通版",
    "priceA": "￥10199.00",
    "num": "2",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191009174856130.jpg",
    "title": "Apple iPhone 11 Pro Max （A2220）全网通版",
    "priceB": "￥10199.00",
    "dis1": "1、6.5英寸OLED屏",
    "dis2": "2、1200万后置三摄",
    "pj": "99%",
    "xd": "1412",
    "zx": "3"
}, {
    "name": "三星 Galaxy Note 10+ （SM-N9760） 全网通5G版",
    "priceA": "￥7999.00",
    "num": "3",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190821095956529.jpg",
    "title": "三星 Galaxy Note 10+ （SM-N9760） 全网通5G版",
    "priceB": "￥7999.00",
    "dis1": "1、高通骁龙855",
    "dis2": "2、超感官全面屏",
    "pj": "100%",
    "xd": "230",
    "zx": "0"
}, {
    "name": "华为 P30 Pro （VOG-AL00）全网通版",
    "priceA": "￥4988.00",
    "num": "4",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190326225205984.jpg",
    "title": "华为 P30 Pro （VOG-AL00）全网通版",
    "priceB": "￥4988.00",
    "dis1": "1、海思麒麟980",
    "dis2": "2、超感光徕卡四摄",
    "pj": "99%",
    "xd": "2901",
    "zx": "11"
}, {
    "name": "vivo NEX 3 全网通5G版",
    "priceA": "￥4998.00",
    "num": "5",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190916202050147.jpg",
    "title": "vivo NEX 3 全网通5G版",
    "priceB": "￥4998.00",
    "dis1": "1、5G双卡双待",
    "dis2": "2、6400万后置三摄",
    "pj": "98%",
    "xd": "310",
    "zx": "0"
}]
let data3 = [{
    "name": "华为 nova 5 Pro （SEA-AL10）全网通版",
    "priceA": "￥2699.00",
    "num": "1",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190614143102844.jpg",
    "title": "华为 nova 5 Pro （SEA-AL10）全网通版",
    "priceB": "￥2699.00",
    "dis1": "1、海思麒麟980",
    "dis2": "2、后置四摄",
    "pj": "99%",
    "xd": "3485",
    "zx": "2"
}, {
    "name": "OPPO Reno 2 全网通版",
    "priceA": "￥2998.00",
    "num": "2",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191008113759261.jpg",
    "title": "OPPO Reno 2 全网通版",
    "priceB": "￥2998.00",
    "dis1": "1、高通骁龙730G",
    "dis2": "2、4800万后置四摄",
    "pj": "98%",
    "xd": "454",
    "zx": "0"
}, {
    "name": "华为 畅享10 Plus （STK-AL00）全网通版",
    "priceA": "￥1799.00",
    "num": "3",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190905153208190.jpg",
    "title": "华为 畅享10 Plus （STK-AL00）全网通版",
    "priceB": "￥1799.00",
    "dis1": "1、4800万后置主摄",
    "dis2": "2、海思麒麟710F",
    "pj": "97%",
    "xd": "1045",
    "zx": "0"
}, {
    "name": "OPPO K5 全网通版",
    "priceA": "￥2598.00",
    "num": "4",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191009143925668.jpg",
    "title": "OPPO K5 全网通版",
    "priceB": "￥2598.00",
    "dis1": "1、高通骁龙730G\n",
    "dis2": "2、畅快游戏体验",
    "pj": "95%",
    "xd": "154",
    "zx": "0"
}, {
    "name": "小米9 Pro 全网通5G版",
    "priceA": "￥4299.00",
    "num": "5",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190923100026167.jpg",
    "title": "小米9 Pro 全网通5G版",
    "priceB": "￥4299.00",
    "dis1": "1、40W超级有线闪充",
    "dis2": "2、5G双卡双待",
    "pj": "98%",
    "xd": "189",
    "zx": "0"
}]
let data4 = [{
    "name": "华为 畅享9 （DUB-AL00） 全网通高配版",
    "priceA": "￥899.00",
    "num": "1",
    "src": "https://img2.ch999img.com/pic/product/160x160/20181210110410215.jpg",
    "title": "华为 畅享9 （DUB-AL00） 全网通高配版",
    "priceB": "￥899.00",
    "dis1": "1、6.",
    "dis2": "26英寸全面屏\n2、4000mAh大电池",
    "pj": "98%",
    "xd": "3472",
    "zx": "5"
}, {
    "name": "华为 荣耀 Play 3 全网通版",
    "priceA": "￥1299.00",
    "num": "2",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190904202828700.jpg",
    "title": "华为 荣耀 Play 3 全网通版",
    "priceB": "￥1299.00",
    "dis1": "1、4800万后置三摄",
    "dis2": "2、4000mAh大电池",
    "pj": "98%",
    "xd": "237",
    "zx": "0"
}, {
    "name": "OPPO A11x 全网通版",
    "priceA": "￥1798.00",
    "num": "3",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191008114050778.jpg",
    "title": "OPPO A11x 全网通版",
    "priceB": "￥1798.00",
    "dis1": "1、4800万后置四摄",
    "dis2": "2、5000mAh大电池",
    "pj": "95%",
    "xd": "395",
    "zx": "0"
}, {
    "name": "华为 荣耀 20 （LRA-AL00）青春版",
    "priceA": "￥1699.00",
    "num": "4",
    "src": "https://img2.ch999img.com/pic/product/160x160/20191018165328791.jpg",
    "title": "华为 荣耀 20 （LRA-AL00）青春版",
    "priceB": "￥1699.00",
    "dis1": "1、4000mAh大电池",
    "dis2": "2、面部识别解锁",
    "pj": "98%",
    "xd": "90",
    "zx": "0"
}, {
    "name": "红米 Redmi Note 8 Pro 全网通版",
    "priceA": "￥1699.00",
    "num": "5",
    "src": "https://img2.ch999img.com/pic/product/160x160/20190829174848571.jpg",
    "title": "红米 Redmi Note 8 Pro 全网通版",
    "priceB": "￥1699.00",
    "dis1": "1、6400万超清模式",
    "dis2": "2、快速充电",
    "pj": "98%",
    "xd": "492",
    "zx": "0"
}]
// var a = document.querySelectorAll(".ph_floor_f")[0].querySelectorAll("li");
// var arr = [];
// for (var i = 0, len = a.length; i < len; i++) {

//     var o = {};
//     o.name = a[i].querySelector(".another_name").innerText;
//     o.priceA = a[i].querySelector(".another_price").innerText;
//     o.num = a[i].querySelector(".icon_ph_number").innerText;
//     o.src = a[i].querySelector("img").src;
//     o.title = a[i].querySelector("h6").innerText;
//     o.priceB = a[i].querySelector(".nowPrice").innerText;
//     o.dis1 = a[i].querySelector(".simple_Title").innerText.slice(0, a[i].querySelector(".simple_Title").innerText.indexOf("2"))
//     o.dis2 = a[i].querySelector(".simple_Title").innerText.slice(a[i].querySelector(".simple_Title").innerText.indexOf("2"))
//     o.pj = a[i].querySelector(".ph_evaluter").querySelector("i").innerText.slice(1, a[i].querySelector(".ph_evaluter").querySelector("i").innerText.indexOf("%") + 1)
//     o.xd = a[i].querySelector(".getxinde").querySelector("span").querySelector("a").innerText;
//     o.zx = a[i].querySelector(".getxinde").querySelector("i").querySelector("a").innerText;
//     arr.push(o);
// }
// console.log(JSON.stringify(arr));